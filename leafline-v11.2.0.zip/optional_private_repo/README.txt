backup-keepalive.yml saves a daily copy of your customer data as a downloadable file.
NEVER put it in your public website repository (anyone signed in to GitHub could download the backup).
Only use it in a separate PRIVATE repository, or simply use ADMIN_TOOLS.bat > Backup on your own computer.
